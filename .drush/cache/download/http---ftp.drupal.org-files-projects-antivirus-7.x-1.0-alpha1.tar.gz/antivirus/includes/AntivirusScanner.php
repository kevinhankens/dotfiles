<?php

/**
 * @file
 *   Definition of AntivirusScanner.
 */

/**
 * @defgroup antivirus_scanners Antivirus Scanners
 * @{
 * Various implementations of antivirus scanners.
 * @}
 */

/**
 * Defines a common interface for an antivirus provider.
 *
 * @ingroup antivirus_scanners
 */
abstract class AntivirusScanner {

  /**
   * The human-readable name of this scanner.
   *
   * @var string
   */
  public $name;

  public function __construct() {
    $this->name = $this->getName();
  }

  /**
   * Allow each scanner to report the version for debugging.
   */
  public abstract function getVersion();

  /**
   * Allow each scanner to report its name for admin purposes.
   */
  public abstract function getName();

  /**
   * Allow scanners a method to verify that they are set up correctly.
   *
   * @return array
   *   An array containing two arrays keyed by 'status' and 'error', each
   *   of which containing a list of strings.
   */
  public abstract function verify();

  /**
   * Scan a file.
   *
   * @param $file
   *   File object to be scanned.
   * @param $options
   *   Array of options for this scan.
   *
   * @return
   *   ANTIVIRUS_SCAN_OK if no viruses found, ANTIVIRUS_SCAN_FOUND if viruses
   *   are found, or ANTIVIRUS_SCAN_ERROR if the scan failed.
   */
  public abstract function scan($file, $options = array());

  /**
   * Configuration form.
   *
   * @param array $form
   *   Form API array to configure this scanner.
   */
  public abstract function configure(&$form);

  /**
   * Save custom values from the configuration form.
   *
   * @param array $values
   *   Form API array of submitted values.
   */
  public abstract function save($values);

}

