<?php

/**
 * Defines an interface for scanners using a local executable file.
 *
 * @ingroup antivirus_scanners
 */
abstract class AntivirusDaemonScanner extends AntivirusScanner { 
  /**
   * The host name of the daemon server.
   *
   * @var string 
   */
  public $host;

  /**
   * The port that the daemon server is listening on.
   *
   * @var string 
   */
  public $port;

  public function __construct() {
    $this->host = $this->getHost();
    $this->port = $this->getPort();
    parent::__construct();
  }

  /**
   * Return flags set for command-line scanner usage.
   */
  final protected function getFlags() {
    $enabled_flags = array();
    $flags = variable_get('antivirus_scanner_' . $this->name . '_flags', array());

    foreach ($flags as $flag => $enabled) {
      if ($enabled) {
        $enabled_flags[] = $flag;
      }
    }

    return $enabled_flags;
  }

  /**
   * Report a path.
   * @todo antivirus.admin.inc shouldn't require a getPath() implementation. Instead 
   */
  public function getPath() {
    return 'none';
  }

  /**
   * Implements AntivirusScanner::verify();
   */
  public function verify() {
    $messages = array();

    $handler = ($this->host && $this->port) ? @fsockopen($this->host, $this->port) : FALSE;

    if ($handler) {
      fclose($handler);
      $messages['status'][] = t('Connected to scanner at %host on port %port.', array('%host' => $this->host, '%port' => $this->port));
    }
    else {
      $messages['error'][] = t('Could not connect to scanner at %host on port %port.', array('%host' => $this->host, '%port' => $this->port));
    }
 
    return $messages;
  }
}
