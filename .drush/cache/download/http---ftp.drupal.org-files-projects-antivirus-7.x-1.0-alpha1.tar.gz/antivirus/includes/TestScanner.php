<?php

/**
 * @file
 *   Definition of TestScanner.
 */

/**
 * Implements a test scanner.
 *
 * Simple test to verify scanning is taking place and results are
 * evaluated. This "scanner" only tests whether a filename has the word
 * "virus" in the name.
 * 
 * @ingroup antivirus_scanners
 */
class TestScanner extends AntivirusExecutableScanner {

  public function __construct() {
    parent::__construct();
  }

  /**
   * Implementation of AntivirusScanner::version().
   */
  public function versionFlags() {
    return NULL;
  }

  /**
   * Implementation of AntivirusScanner:getPath().
   */
  public function getPath() {
    return NULL;
  }

  /**
   * Implementation of AntivirusScanner:getName().
   */
  public function getName() {
    return 'test';
  }

  /**
   * Implementation of AntivirusScanner:verify().
   */
  public function verify() {
  }

  /**
   * Implementation of AntivirusScanner::scan().
   */
  public function scan($file, $options = array(), $debug = FALSE) {
    $result = preg_match('/virus/i', basename($file));

    if ($result > 0) {
      drupal_set_message(t('Virus found in file %file.', array('%file' => $file)), 'warning');
      return ANTIVIRUS_SCAN_FOUND;
    }
    else {
      drupal_set_message(t('No viruses found in %file.', array('%file' => $file)));
      return ANTIVIRUS_SCAN_OK;
    }
  }

  /**
   * Implementation of AntivirusScanner::configure().
   */
  public function configure(&$form) {
    $form = NULL;
  }

  /**
   * Implementation of AntivirusScanner::save().
   */
  public function save($values) {
  }
}
