Put 
jquery.cycle.js
jquery.easing.js

In this directory.
kthxbai
