
Media: YouTube

Creates a YouTube PHP Stream Wrapper for Resource and implements the various
formatter and file listing hooks in the Media module.
