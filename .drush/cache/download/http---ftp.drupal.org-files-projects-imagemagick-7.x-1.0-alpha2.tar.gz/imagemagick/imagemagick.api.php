<?php

/**
 * @file
 * API documentation for ImageMagick module.
 */

