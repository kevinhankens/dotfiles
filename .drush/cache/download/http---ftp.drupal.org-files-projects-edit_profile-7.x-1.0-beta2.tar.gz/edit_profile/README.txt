
INSTRUCTIONS
------------

1. Install this module as you would any other. This will immediately result in
   the "Edit" tab on all user accounts being renamed to "Edit account".

2. If you haven't added any custom user fields yet, you won't yet see an "Edit
   profile" tab. To add user fields, go to Administration > Configuration >
   People > Account settings > Manage fields.

3. Once you've added some fields, all user accounts will get a new "Edit
   profile" tab on which they can edit their own values of the fields you
   added.
